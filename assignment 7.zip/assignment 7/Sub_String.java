import java.util.*;
public class Sub_String{
    public static String removeWord(String string, String word) 
    { 
  
        // Check if the word is present in string 
        // If found, remove it using removeAll() 
        if (string.contains(word)) { 
  
            // To cover the case 
            // if the word is at the 
            // beginning of the string 
            // or anywhere in the middle 
            String tempWord = word + " "; 
            string = string.replaceAll(tempWord, ""); 
  
            // To cover the edge case 
            // if the word is at the 
            // end of the string 
            tempWord = " " + word; 
            string = string.replaceAll(tempWord, ""); 
        } 
  
        // Return the resultant string 
        return string; 
    } 
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String str1="";
        String str2="";
        String str3="";
        System.out.println("Enter String1");
        str1=s.nextLine();
        System.out.println("Enter String2");
        str2=s.nextLine();
        str3=removeWord(str1, str2);
        System.out.println(str3);
    }
}